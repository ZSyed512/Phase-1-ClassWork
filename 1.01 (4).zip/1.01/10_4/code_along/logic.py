x = 5
y = 6

# equals to
print("x == y", x == y)

# greater
print("x > y", x > y)

# less than
print("x < y", x < y)

# greater or equals
print("x >= y", x >= y)

# less than or equals
print("x <= y", x <= y)

# not equal to
print("x != y", x != y)

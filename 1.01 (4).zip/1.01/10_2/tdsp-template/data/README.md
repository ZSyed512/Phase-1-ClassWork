# data 

This is where we store sample data for simple modeling.

For demonstration, we will use the [baby names dataset](https://catalog.data.gov/dataset/popular-baby-names) from data.gov 
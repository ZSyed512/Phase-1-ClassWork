"""
basic data types
"""

# numeric: integer
num1 = 3
num2 = num1 + 2

# numeric: float
pi = 3.14

# string
word = "hello"

# boolean
on = True
off = False
foobar = True

print(word)
print(pi)
print(word, pi)

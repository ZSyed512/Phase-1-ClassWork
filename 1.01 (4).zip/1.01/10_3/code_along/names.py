"""
Variables can be named whatever your heart desires (with a few rules).

BUT that does not mean you should desire such things.
"""

TKH = 3

TKH23 = 10

TKHhhhhhhhhhhhhhhh = 25

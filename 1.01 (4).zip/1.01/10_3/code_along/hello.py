# TODO: type first (maybe) line of code below
...

# run with python hello.py

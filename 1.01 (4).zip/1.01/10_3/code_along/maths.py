# TODO:

# part 1
...

# part 2
...

# part 3
...

# run via python maths.py

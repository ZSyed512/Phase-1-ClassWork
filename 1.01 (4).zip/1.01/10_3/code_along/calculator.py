# take in one number
x = ...

# take in another
y = ...

# add together and print
